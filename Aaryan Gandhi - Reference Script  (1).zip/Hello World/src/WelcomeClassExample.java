//This line import's jav's user input method
import java.util.Scanner;

//This class is created to hold all other classes
public class WelcomeClassExample {
	
	//This line of code allows the program to execute
	public static void main(String[] args) 
		{
			//This calls the function
			codeReference();
	    }
	
	//This function holds all of the running code
	public static void codeReference() {
		Scanner Main = new Scanner(System.in);
		
		//These 2 lines introduce the program
		System.out.println("This is my Java Reference Script\n");
	 	System.out.println("Pick a number between 1 and 10: ");
	 	
	 	//This integer variable takes whatever value given by user
	 	int randomNumber = Main.nextInt();
	 	
	 	//These statements print the number given by user
	 	System.out.println("Your number is " + randomNumber);
	 	System.out.println("");
	 	
	 	//This for loop prints the statement the amount of times given by user
	 	for(int i=0;i<randomNumber;i++) {
	 	    System.out.println("This prints " + randomNumber + " times");
	    }
	    //This line closes the Java file
	    Main.close();
	}
}

